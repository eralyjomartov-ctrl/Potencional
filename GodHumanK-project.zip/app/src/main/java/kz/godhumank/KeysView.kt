package kz.godhumank

import android.content.Context
import android.graphics.*
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import java.util.Locale
import kotlin.math.abs
import kotlin.math.min

class KeysView(ctx: Context, private val svc: GodHumanKService, private val rowH: Float) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private fun dp(v: Float) = v * d

    var page = 0
        private set
    var shift = 0            // 0 выкл, 1 одна буква, 2 постоянно (двойное нажатие)
    private var lastShiftTap = 0L

    private class Cell(val key: Key, val l: Float, val t: Float, val r: Float, val b: Float, val row: Int)

    private var cells = listOf<Cell>()
    private val gap = dp(6f)          // видимый промежуток; хитбоксы касаются друг друга
    private val h = Handler(Looper.getMainLooper())
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = dp(1f); color = Color.parseColor("#9AA5B5") }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT }

    private var pressed: Cell? = null
    private var popup: List<String>? = null
    private var popupCell: Cell? = null
    private var popupLeft = 0f
    private var popupW = 0f
    private var popupSel = 0
    private var popupInit = 0
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var downTime = 0L
    private var gesture = false
    private var downBack = false
    private var moved = false

    private val repeatRun = object : Runnable {
        override fun run() { svc.backspace(); h.postDelayed(this, 50) }
    }
    private val startRepeat = Runnable { repeatRun.run() }
    private val longRun = Runnable {
        val c = pressed ?: return@Runnable
        val items = altsOf(c)
        if (items.isEmpty()) return@Runnable
        val n = items.size
        popupW = min(dp(44f), width.toFloat() / n)
        popupLeft = c.l.coerceIn(0f, (width - n * popupW).coerceAtLeast(0f))
        popup = items
        popupCell = c
        updateSel(lastX)
        popupInit = popupSel
        invalidate()
    }

    fun setPage(p: Int) { page = p; relayout(); invalidate() }

    override fun onMeasure(w: Int, hh: Int) = setMeasuredDimension(MeasureSpec.getSize(w), (rowH * 4).toInt())
    override fun onSizeChanged(w: Int, hh: Int, ow: Int, oh: Int) { relayout() }

    private fun relayout() {
        val w = width.toFloat()
        if (w <= 0f) return
        val rows = Layouts.rows(page)
        val tot = rows.map { r -> r.keys.fold(0f) { a, k -> a + k.weight } }
        val ref = rows.indices.filter { !rows[it].fill }.maxOf { tot[it] }
        val unit = w / ref
        val list = ArrayList<Cell>()
        rows.forEachIndexed { i, r ->
            val u = if (r.fill) w / tot[i] else unit
            var x = if (r.fill) 0f else (w - tot[i] * unit) / 2f
            for (k in r.keys) {
                val kw = k.weight * u
                list.add(Cell(k, x, i * rowH, x + kw, (i + 1) * rowH, i))
                x += kw
            }
        }
        cells = list
    }

    private fun letters() = page <= 1
    private fun labelOf(k: Key): String = when (k.type) {
        KT.CHAR -> if (letters() && shift != 0) k.label.uppercase(Locale.ROOT) else k.label
        KT.SHIFT -> if (shift == 2) "⇪" else "⇧"
        KT.BACK -> "⌫"
        else -> k.label
    }
    private fun altsOf(c: Cell): List<String> =
        c.key.alts.map { if (letters() && shift != 0) it.uppercase(Locale.ROOT) else it }

    override fun onDraw(c: Canvas) {
        c.drawColor(Cfg.BG)
        for (cell in cells) {
            val k = cell.key
            val r = RectF(cell.l + gap / 2, cell.t + gap / 2, cell.r - gap / 2, cell.b - gap / 2)
            val isP = cell === pressed
            fill.color = when {
                k.type == KT.ENTER -> if (isP) Cfg.ENTER_PRESSED else Cfg.ENTER
                isP -> Cfg.PRESSED
                k.type == KT.SHIFT && shift != 0 -> Color.parseColor("#BFD0F0")
                k.type == KT.SHIFT || k.type == KT.BACK || k.type == KT.PAGE -> Cfg.SPECIAL
                else -> Cfg.KEY
            }
            c.drawRoundRect(r, dp(8f), dp(8f), fill)
            txt.color = if (k.type == KT.ENTER) Color.WHITE else Color.parseColor("#111111")
            txt.textSize = if (k.type == KT.CHAR) rowH * 0.42f else rowH * 0.3f
            val label = labelOf(k)
            c.drawText(label, r.centerX(), r.centerY() - (txt.descent() + txt.ascent()) / 2, txt)
        }
        val p = popup
        val pc = popupCell
        if (p != null && pc != null) {
            val top = if (pc.row > 0) pc.t - rowH else pc.t
            val rect = RectF(popupLeft, top + gap / 2, popupLeft + p.size * popupW, top + rowH - gap / 2)
            fill.color = Color.WHITE
            c.drawRoundRect(rect, dp(8f), dp(8f), fill)
            c.drawRoundRect(rect, dp(8f), dp(8f), border)
            p.forEachIndexed { i, s ->
                val ir = RectF(popupLeft + i * popupW, rect.top, popupLeft + (i + 1) * popupW, rect.bottom)
                if (i == popupSel) {
                    fill.color = Cfg.ENTER
                    c.drawRoundRect(ir, dp(8f), dp(8f), fill)
                }
                txt.color = if (i == popupSel) Color.WHITE else Color.parseColor("#111111")
                txt.textSize = rowH * 0.4f
                c.drawText(s, ir.centerX(), ir.centerY() - (txt.descent() + txt.ascent()) / 2, txt)
            }
        }
    }

    private fun hit(x: Float, y: Float): Cell? {
        val xx = x.coerceIn(0f, width - 0.5f)
        val yy = y.coerceIn(0f, height - 0.5f)
        return cells.firstOrNull { xx >= it.l && xx < it.r && yy >= it.t && yy < it.b }
    }

    private fun updateSel(x: Float) {
        val n = popup?.size ?: return
        popupSel = ((x - popupLeft) / popupW).toInt().coerceIn(0, n - 1)
        if (popupSel != popupInit) moved = true
    }

    private fun cancelTimers() {
        h.removeCallbacks(longRun); h.removeCallbacks(startRepeat); h.removeCallbacks(repeatRun)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x = e.x
        val y = e.y
        lastX = x
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = x; downY = y; gesture = false; moved = false; downTime = e.eventTime
                popup = null
                pressed = hit(x, y)
                downBack = pressed?.key?.type == KT.BACK
                val c = pressed
                if (c != null) {
                    if (downBack) { svc.backspace(); h.postDelayed(startRepeat, 400) }
                    else if (c.key.alts.isNotEmpty()) h.postDelayed(longRun, Cfg.LONG_PRESS_MS)
                }
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> onMove(x, y)
            MotionEvent.ACTION_UP -> onUp(e)
            MotionEvent.ACTION_CANCEL -> { cancelTimers(); popup = null; pressed = null; invalidate() }
        }
        return true
    }

    private inline fun fire(a: () -> Unit) {
        cancelTimers(); gesture = true; pressed = null; a(); invalidate()
    }

    private fun onMove(x: Float, y: Float) {
        if (popup != null) { updateSel(x); invalidate(); return }
        if (gesture) return
        val dx = x - downX
        val dy = y - downY
        if (downBack) {
            if (dx < -dp(40f)) {   // удерживать ⌫ и провести влево — удалить слово
                h.removeCallbacks(startRepeat); h.removeCallbacks(repeatRun)
                svc.deleteWord(); downX = x
            }
            return
        }
        val horiz = abs(dx) > abs(dy) * 1.5f
        when {
            horiz && dx > dp(80f) -> fire { svc.typeText(" ") }          // слева направо — пробел
            horiz && dx < -dp(120f) -> fire { svc.deleteAll() }          // справа налево — удалить всё
            dy > dp(70f) && dy > abs(dx) * 1.5f -> fire { svc.hide() }   // сверху вниз — закрыть
            else -> {
                val n = hit(x, y)
                if (n !== pressed) {
                    h.removeCallbacks(longRun)
                    pressed = n
                    if (n != null && n.key.type != KT.BACK && n.key.alts.isNotEmpty()) h.postDelayed(longRun, Cfg.LONG_PRESS_MS)
                    invalidate()
                }
            }
        }
    }

    private fun onUp(e: MotionEvent) {
        cancelTimers()
        val p = popup
        if (p != null) {
            val c = popupCell!!
            val s = popupSel
            popup = null; pressed = null
            val cancelled = c.key.type == KT.PAGE && !moved && e.eventTime - downTime >= Cfg.SWIPE_SWITCH_MS
            if (!cancelled && s in p.indices) {
                svc.typeText(p[s])
                if (c.key.type == KT.PAGE) setPage(svc.lang)      // после выбора символа — обратно к ABC
                else if (shift == 1) { shift = 0 }
            }
            invalidate(); return
        }
        val c = pressed
        pressed = null
        if (!gesture && !downBack && c != null) commit(c.key)
        invalidate()
    }

    private fun commit(k: Key) {
        when (k.type) {
            KT.CHAR -> {
                svc.typeText(labelOf(k))
                if (shift == 1) shift = 0
            }
            KT.SHIFT -> {
                val now = System.currentTimeMillis()
                shift = if (shift == 1 && now - lastShiftTap < 350) 2 else if (shift == 0) 1 else 0
                lastShiftTap = now
            }
            KT.BACK -> svc.backspace()
            KT.PAGE -> setPage(if (k.target == -1) svc.lang else k.target)
            KT.ENTER -> svc.enter()
            KT.SPACE -> svc.typeText(" ")
        }
    }
}
