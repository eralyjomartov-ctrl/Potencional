package kz.godhumank

import android.content.ClipboardManager
import android.content.Configuration
import android.inputmethodservice.InputMethodService
import android.os.SystemClock
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.FrameLayout
import android.widget.LinearLayout
import org.json.JSONArray

class GodHumanKService : InputMethodService() {
    private class U(var before: String, var after: String)

    var lang = 0                       // 0 = казахский, 1 = английский
    private lateinit var keys: KeysView
    private lateinit var emoji: EmojiPanel
    private lateinit var clipPanel: ClipPanel
    private var built = false
    private var sig = ""
    private var panel = 0
    private val undo = ArrayDeque<U>()
    private var lastWasBs = false
    private var lastBs = 0L

    override fun onCreate() {
        super.onCreate()
        lang = Prefs.sp(this).getInt("lang", 0)
        val cm = getSystemService(ClipboardManager::class.java)
        cm.addPrimaryClipChangedListener {
            try {
                val c = cm.primaryClip
                if (c != null && c.itemCount > 0) {
                    val t = c.getItemAt(0).coerceToText(this)?.toString()
                    if (!t.isNullOrBlank()) addClip(t)
                }
            } catch (_: Exception) {}
        }
    }

    // ---- никакого полноэкранного режима ----
    override fun onEvaluateFullscreenMode() = false

    private fun dp(v: Int) = v * resources.displayMetrics.density

    private fun currentSig(): String {
        val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        return "$land|${Prefs.int(this, "p_h", 52)}|${Prefs.int(this, "p_w", 100)}|${Prefs.int(this, "l_h", 42)}|${Prefs.int(this, "l_w", 100)}"
    }

    private fun buildView(): View {
        val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val pre = if (land) "l_" else "p_"
        val rowH = dp(Prefs.int(this, pre + "h", if (land) 42 else 52))
        val wPct = Prefs.int(this, pre + "w", 100)
        sig = currentSig()

        val top = TopBar(this, this, rowH * 0.8f)
        keys = KeysView(this, this, rowH)
        keys.setPage(lang)
        emoji = EmojiPanel(this, this, rowH)
        clipPanel = ClipPanel(this, this, rowH)
        emoji.visibility = View.GONE
        clipPanel.visibility = View.GONE

        val content = FrameLayout(this)
        content.addView(keys, FrameLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        content.addView(emoji, FrameLayout.LayoutParams(-1, (rowH * 4).toInt()))
        content.addView(clipPanel, FrameLayout.LayoutParams(-1, (rowH * 4).toInt()))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(top, LinearLayout.LayoutParams(-1, (rowH * 0.8f).toInt()))
        col.addView(content, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))

        val screenW = resources.displayMetrics.widthPixels
        val root = FrameLayout(this)
        root.setBackgroundColor(Cfg.BG)
        root.setPadding(0, 0, 0, 0)
        root.addView(col, FrameLayout.LayoutParams((screenW * wPct / 100f).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL))
        built = true
        panel = 0
        // нижняя системная полоса — в цвет клавиатуры, без белой полосы
        try { window.window?.navigationBarColor = Cfg.BG } catch (_: Exception) {}
        return root
    }

    override fun onCreateInputView(): View = buildView()

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        setInputView(buildView())      // автопереключение настроек портрет/ландшафт
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        setExtractViewShown(false)
        if (!restarting) undo.clear()
        if (built && sig != currentSig()) setInputView(buildView())
        if (built) { showPanel(0); keys.shift = 0; keys.setPage(lang) }
    }

    // ---- панели ----
    fun showPanel(p: Int) {
        if (!built) return
        panel = p
        keys.visibility = if (p == 0) View.VISIBLE else View.GONE
        emoji.visibility = if (p == 1) View.VISIBLE else View.GONE
        clipPanel.visibility = if (p == 2) View.VISIBLE else View.GONE
        if (p == 2) clipPanel.refresh()
    }

    fun togglePanel(p: Int) = showPanel(if (panel == p) 0 else p)

    fun toggleLang() {
        lang = 1 - lang
        Prefs.sp(this).edit().putInt("lang", lang).apply()
        showPanel(0)
        keys.shift = 0
        keys.setPage(lang)
    }

    fun hide() = requestHideSelf(0)

    // ---- ввод ----
    fun typeText(t: String) {
        currentInputConnection?.commitText(t, 1)
        lastWasBs = false
    }

    fun enter() {
        val ic = currentInputConnection ?: return
        val ei = currentInputEditorInfo
        val a = (ei?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        if (ei == null || (ei.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0 ||
            a == EditorInfo.IME_ACTION_NONE || a == EditorInfo.IME_ACTION_UNSPECIFIED
        ) sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER) else ic.performEditorAction(a)
        lastWasBs = false
    }

    private fun push(u: U) {
        undo.addLast(u)
        if (undo.size > 100) undo.removeFirst()
    }

    fun backspace() {
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)
        if (!sel.isNullOrEmpty()) {
            push(U(sel.toString(), "")); ic.commitText("", 1); lastWasBs = false; return
        }
        val b = ic.getTextBeforeCursor(2, 0)
        if (b.isNullOrEmpty()) { sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL); return }
        var n = 1
        if (b.length == 2 && Character.isHighSurrogate(b[0]) && Character.isLowSurrogate(b[1])) n = 2
        val del = b.subSequence(b.length - n, b.length).toString()
        val now = SystemClock.uptimeMillis()
        val top = undo.lastOrNull()
        if (top != null && lastWasBs && top.after.isEmpty() && now - lastBs < 1500) top.before = del + top.before
        else push(U(del, ""))
        lastBs = now; lastWasBs = true
        ic.deleteSurroundingText(n, 0)
    }

    fun deleteWord() {
        val ic = currentInputConnection ?: return
        val b = ic.getTextBeforeCursor(200, 0)?.toString() ?: return
        if (b.isEmpty()) return
        var i = b.length
        while (i > 0 && b[i - 1].isWhitespace()) i--
        while (i > 0 && !b[i - 1].isWhitespace()) i--
        val del = b.substring(i)
        push(U(del, ""))
        ic.deleteSurroundingText(del.length, 0)
        lastWasBs = false
    }

    fun deleteAll() {
        val ic = currentInputConnection ?: return
        val b = ic.getTextBeforeCursor(100000, 0)?.toString() ?: ""
        val a = ic.getTextAfterCursor(100000, 0)?.toString() ?: ""
        if (b.isEmpty() && a.isEmpty()) return
        push(U(b, a))
        ic.beginBatchEdit()
        ic.deleteSurroundingText(b.length, a.length)
        ic.endBatchEdit()
        lastWasBs = false
    }

    fun undoLast() {
        val ic = currentInputConnection ?: return
        val u = undo.removeLastOrNull() ?: return
        ic.beginBatchEdit()
        ic.commitText(u.before, 1)
        if (u.after.isNotEmpty()) ic.commitText(u.after, 0)   // курсор остаётся между частями
        ic.endBatchEdit()
        lastWasBs = false
    }

    // ---- буфер обмена ----
    fun clips(): List<String> {
        val a = JSONArray(Prefs.sp(this).getString("clips", "[]"))
        return List(a.length()) { a.getString(it) }
    }

    private fun saveClips(l: List<String>) {
        Prefs.sp(this).edit().putString("clips", JSONArray(l).toString()).apply()
    }

    private fun addClip(t: String) {
        val l = clips().toMutableList()
        l.remove(t); l.add(0, t)
        saveClips(l.take(50))
    }

    fun removeClip(i: Int) { val l = clips().toMutableList(); if (i in l.indices) { l.removeAt(i); saveClips(l) } }
    fun clearClips() = saveClips(emptyList())
}
