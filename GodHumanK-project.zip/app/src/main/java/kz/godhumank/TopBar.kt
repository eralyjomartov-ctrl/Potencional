package kz.godhumank

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View

/** Компактная верхняя панель: справа ↶, Emoji, глобус, буфер. */
class TopBar(ctx: Context, private val svc: GodHumanKService, private val barH: Float) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.BLACK; strokeWidth = 1.8f * d }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; color = Color.BLACK }
    private var pressedIdx = -1
    private val n = 4
    private fun bw() = barH * 1.2f

    private fun idxAt(x: Float): Int {
        val start = width - n * bw()
        val i = ((x - start) / bw()).toInt()
        return if (x >= start && i in 0 until n) i else -1
    }

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(MeasureSpec.getSize(w), barH.toInt())

    override fun onDraw(c: Canvas) {
        c.drawColor(Cfg.BG)
        val start = width - n * bw()
        for (i in 0 until n) {
            val cx = start + i * bw() + bw() / 2
            val cy = height / 2f
            if (i == pressedIdx) {
                fill.color = Cfg.PRESSED
                c.drawRoundRect(cx - bw() / 2 + 3 * d, 3 * d, cx + bw() / 2 - 3 * d, height - 3 * d, 8 * d, 8 * d, fill)
            }
            when (i) {
                0 -> text(c, "↶", cx, cy, barH * 0.55f)
                1 -> text(c, "🙂", cx, cy, barH * 0.5f)
                2 -> globe(c, cx, cy, barH * 0.28f)
                3 -> text(c, "📋", cx, cy, barH * 0.45f)
            }
        }
    }

    private fun text(c: Canvas, s: String, cx: Float, cy: Float, size: Float) {
        txt.textSize = size
        c.drawText(s, cx, cy - (txt.descent() + txt.ascent()) / 2, txt)
    }

    private fun globe(c: Canvas, cx: Float, cy: Float, r: Float) {
        c.drawCircle(cx, cy, r, line)
        c.drawOval(RectF(cx - r * 0.45f, cy - r, cx + r * 0.45f, cy + r), line)
        c.drawLine(cx - r, cy, cx + r, cy, line)
        c.drawLine(cx, cy - r, cx, cy + r, line)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> { pressedIdx = idxAt(e.x); invalidate() }
            MotionEvent.ACTION_UP -> {
                val i = idxAt(e.x)
                pressedIdx = -1; invalidate()
                when (i) {
                    0 -> svc.undoLast()
                    1 -> svc.togglePanel(1)
                    2 -> svc.toggleLang()
                    3 -> svc.togglePanel(2)
                }
            }
            MotionEvent.ACTION_CANCEL -> { pressedIdx = -1; invalidate() }
        }
        return true
    }
}
