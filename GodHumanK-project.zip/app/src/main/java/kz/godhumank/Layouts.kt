package kz.godhumank

enum class KT { CHAR, SHIFT, BACK, PAGE, ENTER, SPACE }

class Key(
    val label: String,
    val type: KT = KT.CHAR,
    val weight: Float = 1f,
    val alts: List<String> = emptyList(),
    val target: Int = 0
)

class Row(val keys: List<Key>, val fill: Boolean = false)

/** Страницы: 0 = казахская, 1 = английская, 2 = ?123, 3 = =\< */
object Layouts {
    private val kkAlts = mapOf(
        "й" to listOf("1"), "ц" to listOf("2"), "у" to listOf("ү", "ұ", "3"), "к" to listOf("қ", "4"),
        "е" to listOf("ё", "5"), "н" to listOf("ң", "6"), "г" to listOf("ғ", "7"), "ш" to listOf("8"),
        "щ" to listOf("9"), "з" to listOf("0"), "а" to listOf("ә"), "и" to listOf("і"), "ы" to listOf("і"),
        "о" to listOf("ө"), "х" to listOf("һ")
    )
    private val enAlts = mapOf(
        "q" to listOf("1"), "w" to listOf("2"), "e" to listOf("3"), "r" to listOf("4"), "t" to listOf("5"),
        "y" to listOf("6"), "u" to listOf("7"), "i" to listOf("8"), "o" to listOf("9"), "p" to listOf("0")
    )
    private val symAlts = mapOf(
        "1" to listOf("¹", "½", "⅓", "¼"), "2" to listOf("²", "⅔"), "3" to listOf("³", "¾"),
        "4" to listOf("⁴"), "5" to listOf("⁵"), "0" to listOf("⁰", "∅", "°"),
        "₸" to listOf("$", "€", "£", "¥", "¢", "₽", "₴", "₿"),
        "-" to listOf("–", "—", "_", "‑"), "/" to listOf("\\", "÷"),
        "(" to listOf("[", "{", "<"), ")" to listOf("]", "}", ">"),
        "\"" to listOf("“", "”", "«", "»", "„"), "'" to listOf("‘", "’", "‹", "›", "‚"),
        "!" to listOf("¡", "‼"), "?" to listOf("¿", "⁇"), "*" to listOf("†", "‡", "★", "☆"),
        "#" to listOf("№", "§"), "%" to listOf("‰", "‱"), "+" to listOf("±", "∓"),
        "&" to listOf("@"), "=" to listOf("≠", "≈", "≤", "≥", "±", "∞"),
        "<" to listOf("≤", "«", "‹"), ">" to listOf("≥", "»", "›"),
        "~" to listOf("≈", "∼"), "`" to listOf("´", "¨", "¯"), "|" to listOf("¦", "‖", "¬"),
        "•" to listOf("◦", "▪", "→", "←", "↑", "↓", "✓", "✗"),
        "√" to listOf("∛", "∜", "∑", "∏", "∫"), "π" to listOf("∞", "∂", "τ"),
        "×" to listOf("·", "⋅"), "÷" to listOf("/", "∕"), "¶" to listOf("§", "†"),
        "∆" to listOf("∇", "Ω", "µ", "Σ"), "^" to listOf("ˆ", "¯"), "°" to listOf("′", "″"),
        "£" to listOf("€", "$", "¥"), "€" to listOf("$", "£", "¥"), "¥" to listOf("$", "€", "£"),
        "©" to listOf("℗", "℠"), "®" to listOf("™"), "™" to listOf("℠", "®"),
        "{" to listOf("}"), "[" to listOf("]")
    )
    private val moneyPopup = listOf("₸", "$", "€", "£", "¥", "№", "§", "°", "%", "•")

    private fun chars(s: String, alts: Map<String, List<String>>) =
        s.split(" ").map { Key(it, KT.CHAR, 1f, alts[it] ?: emptyList()) }

    private fun bottom(symbolsKey: Key) = Row(
        listOf(
            symbolsKey,
            Key(",", KT.CHAR, 1f, listOf("'", "\"", ";", ":")),
            Key(" ", KT.SPACE, 5f),
            Key(".", KT.CHAR, 1f, listOf("…", "?", "!", "-")),
            Key("Ввод", KT.ENTER, 2f)
        ), fill = true
    )

    private val toSym = Key("?123", KT.PAGE, 1.5f, moneyPopup, 2)
    private val toAbc = Key("ABC", KT.PAGE, 1.5f, emptyList(), -1)
    private fun shift() = Key("⇧", KT.SHIFT, 1.5f)
    private fun back() = Key("⌫", KT.BACK, 1.5f)

    fun rows(page: Int): List<Row> = when (page) {
        0 -> listOf(
            Row(chars("й ц у к е н г ш щ з х ъ", kkAlts)),
            Row(chars("ф ы в а п р о л д ж э", kkAlts)),
            Row(listOf(shift()) + chars("я ч с м и т ь б ю", kkAlts) + back()),
            bottom(toSym)
        )
        1 -> listOf(
            Row(chars("q w e r t y u i o p", enAlts)),
            Row(chars("a s d f g h j k l", enAlts)),
            Row(listOf(shift()) + chars("z x c v b n m", enAlts) + back()),
            bottom(toSym)
        )
        2 -> listOf(
            Row(chars("1 2 3 4 5 6 7 8 9 0", symAlts)),
            Row(chars("@ # ₸ % & - + ( ) /", symAlts)),
            Row(listOf(Key("=\\<", KT.PAGE, 1.5f, emptyList(), 3)) + chars("* \" ' : ; ! ?", symAlts) + back()),
            bottom(toAbc)
        )
        else -> listOf(
            Row(chars("~ ` | • √ π ÷ × ¶ ∆", symAlts)),
            Row(chars("£ ¢ € ¥ ^ ° = { } \\", symAlts)),
            Row(listOf(Key("?123", KT.PAGE, 1.5f, emptyList(), 2)) + chars("© ® ™ [ ] < >", symAlts) + back()),
            bottom(toAbc)
        )
    }
}
