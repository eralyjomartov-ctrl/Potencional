package kz.godhumank

object Emoji {
    private const val SMILES = "😀 😃 😄 😁 😆 😅 😂 🤣 🥲 ☺️ 😊 😇 🙂 🙃 😉 😌 😍 🥰 😘 😗 😙 😚 😋 😛 😝 😜 🤪 🤨 🧐 🤓 😎 🥸 🤩 🥳 😏 😒 😞 😔 😟 😕 🙁 ☹️ 😣 😖 😫 😩 🥺 😢 😭 😤 😠 😡 🤬 🤯 😳 🥵 🥶 😱 😨 😰 😥 😓 🤗 🤔 🫣 🤭 🫢 🫡 🤫 🫠 🤥 😶 😐 😑 😬 🙄 😯 😦 😧 😮 😲 🥱 😴 🤤 😪 😵 🤐 🥴 🤢 🤮 🤧 😷 🤒 🤕 🤑 🤠 😈 👿 👹 👺 🤡 💩 👻 💀 ☠️ 👽 🤖"
    private const val REACTIONS = "👍 👎 👏 🙌 🔥 💯 ✨ ⭐ 🌟 🎉 🎊 💥 💫 👀 ✅ ❌ ❓ ❗ 💬"
    private const val HEARTS = "❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 ❣️ 💕 💞 💓 💗 💖 💘 💝 💟 ❤️‍🔥 ❤️‍🩹"
    private const val USER = "❤️‍🩹 👋 🤚 🖐️ ✋ 🖖 🫱 🫲 🫳 🫴 🫷 🫸 👌 🤌 🤏 ✌️ 🤞 🫰 🤟 🤘 🤙 👈 👉 👆 🖕 👇 ☝️ 🫵 👍 👎 🤜 👏 🫶 🙌 👐 🤲 ✊ 👊 🤝 🙏 🤛 🎁 🥇 🥈 🥉 💸 💵 🪎 💰 ⛏️ ⚒️ 🛠️ 🗡️ ⚔️ 🔨 🪛 🪚 🔧 🗝️ 🛡️ 💣 🪃 🏹 🪓 🗑️ 🧲 💊 🩸 🪤 🇰🇿"

    val all: List<String> = (SMILES.split(" ") + REACTIONS.split(" ") + HEARTS.split(" ") + USER.split(" ")).distinct()
}
