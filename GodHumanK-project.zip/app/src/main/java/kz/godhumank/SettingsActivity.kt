package kz.godhumank

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.*

class SettingsActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val d = resources.displayMetrics.density
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding((16 * d).toInt(), (16 * d).toInt(), (16 * d).toInt(), (16 * d).toInt())

        val title = TextView(this); title.text = "GodHumanK"; title.textSize = 26f
        col.addView(title)

        val b1 = Button(this); b1.text = "1. Включить клавиатуру"
        b1.setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        val b2 = Button(this); b2.text = "2. Выбрать GodHumanK"
        b2.setOnClickListener { getSystemService(InputMethodManager::class.java).showInputMethodPicker() }
        col.addView(b1); col.addView(b2)

        section(col, "Вертикальный режим")
        seek(col, "Высота клавиши", "p_h", 36, 80, 52, "dp")
        seek(col, "Ширина клавиатуры", "p_w", 60, 100, 100, "%")
        section(col, "Горизонтальный режим")
        seek(col, "Высота клавиши", "l_h", 28, 70, 42, "dp")
        seek(col, "Ширина клавиатуры", "l_w", 60, 100, 100, "%")

        val test = EditText(this); test.hint = "Поле для проверки"
        col.addView(test)

        val sv = ScrollView(this); sv.addView(col)
        setContentView(sv)
    }

    private fun section(p: LinearLayout, t: String) {
        val tv = TextView(this); tv.text = t; tv.textSize = 18f
        tv.setPadding(0, (20 * resources.displayMetrics.density).toInt(), 0, 0)
        p.addView(tv)
    }

    private fun seek(p: LinearLayout, title: String, key: String, min: Int, max: Int, def: Int, unit: String) {
        val sp = Prefs.sp(this)
        val tv = TextView(this)
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = sp.getInt(key, def) - min
        tv.text = "$title: ${sp.getInt(key, def)} $unit"
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, pr: Int, u: Boolean) {
                val v = pr + min
                sp.edit().putInt(key, v).apply()
                tv.text = "$title: $v $unit"
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        p.addView(tv); p.addView(sb)
    }
}
