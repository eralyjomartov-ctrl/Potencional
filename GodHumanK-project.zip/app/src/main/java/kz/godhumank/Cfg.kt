package kz.godhumank

import android.content.Context
import android.graphics.Color

object Cfg {
    const val LONG_PRESS_MS = 327L      // показ доп. символов при удержании
    const val SWIPE_SWITCH_MS = 1000L   // задержка для переключения ?123/ABC удержанием
    val BG = Color.parseColor("#E8EBF0")
    val KEY = Color.WHITE
    val SPECIAL = Color.parseColor("#D3D9E2")
    val PRESSED = Color.parseColor("#B3C0D4")
    val ENTER = Color.parseColor("#070D23")
    val ENTER_PRESSED = Color.parseColor("#2A3358")
}

object Prefs {
    fun sp(c: Context) = c.getSharedPreferences("ghk", Context.MODE_PRIVATE)
    fun int(c: Context, k: String, d: Int) = sp(c).getInt(k, d)
}
