package kz.godhumank

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

object Panels {
    fun btn(ctx: Context, text: String, bg: Int, fg: Int, click: () -> Unit): TextView {
        val d = ctx.resources.displayMetrics.density
        return TextView(ctx).apply {
            this.text = text; gravity = Gravity.CENTER; setTextColor(fg); textSize = 16f
            background = GradientDrawable().apply { setColor(bg); cornerRadius = 8 * d }
            setOnClickListener { click() }
        }
    }

    fun bar(ctx: Context, items: List<TextView>): LinearLayout {
        val d = ctx.resources.displayMetrics.density
        val m = (3 * d).toInt()
        return LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            items.forEach {
                val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                lp.setMargins(m, m, m, m)
                addView(it, lp)
            }
        }
    }
}

class EmojiPanel(ctx: Context, svc: GodHumanKService, rowH: Float) : LinearLayout(ctx) {
    init {
        val d = ctx.resources.displayMetrics.density
        orientation = VERTICAL
        setBackgroundColor(Cfg.BG)
        val grid = GridView(ctx)
        grid.numColumns = 8
        grid.adapter = object : BaseAdapter() {
            override fun getCount() = Emoji.all.size
            override fun getItem(i: Int) = Emoji.all[i]
            override fun getItemId(i: Int) = i.toLong()
            override fun getView(i: Int, v: View?, p: ViewGroup?): View {
                val t = (v as? TextView) ?: TextView(ctx).apply {
                    gravity = Gravity.CENTER; textSize = 24f; setTextColor(Color.BLACK)
                    layoutParams = AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (44 * d).toInt())
                }
                t.text = Emoji.all[i]
                return t
            }
        }
        grid.setOnItemClickListener { _, _, i, _ -> svc.typeText(Emoji.all[i]) }
        addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val bar = Panels.bar(ctx, listOf(
            Panels.btn(ctx, "ABC", Cfg.SPECIAL, Color.BLACK) { svc.showPanel(0) },
            Panels.btn(ctx, "⌫", Cfg.SPECIAL, Color.BLACK) { svc.backspace() }
        ))
        addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, rowH.toInt()))
    }
}

class ClipPanel(ctx: Context, private val svc: GodHumanKService, rowH: Float) : LinearLayout(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private var items = listOf<String>()
    private val list = ListView(ctx)
    private val empty = TextView(ctx)
    private val adapter = object : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(i: Int) = items[i]
        override fun getItemId(i: Int) = i.toLong()
        override fun getView(i: Int, v: View?, p: ViewGroup?): View {
            val t = (v as? TextView) ?: TextView(ctx).apply {
                setPadding((12 * d).toInt(), (10 * d).toInt(), (12 * d).toInt(), (10 * d).toInt())
                maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END
                setTextColor(Color.BLACK); textSize = 15f
                background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = 8 * d }
            }
            t.text = items[i]
            return t
        }
    }

    init {
        orientation = VERTICAL
        setBackgroundColor(Cfg.BG)
        list.adapter = adapter
        list.divider = ColorDrawable(Color.TRANSPARENT)
        list.dividerHeight = (6 * d).toInt()
        list.setOnItemClickListener { _, _, i, _ -> svc.typeText(items[i]) }
        list.setOnItemLongClickListener { _, _, i, _ -> svc.removeClip(i); refresh(); true }
        empty.text = "Буфер пуст"; empty.gravity = Gravity.CENTER; empty.setTextColor(Color.GRAY)
        val frame = FrameLayout(ctx)
        frame.addView(list, FrameLayout.LayoutParams(-1, -1))
        frame.addView(empty, FrameLayout.LayoutParams(-1, -1))
        addView(frame, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val bar = Panels.bar(ctx, listOf(
            Panels.btn(ctx, "ABC", Cfg.SPECIAL, Color.BLACK) { svc.showPanel(0) },
            Panels.btn(ctx, "Очистить", Cfg.SPECIAL, Color.BLACK) { svc.clearClips(); refresh() }
        ))
        addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, rowH.toInt()))
    }

    fun refresh() {
        items = svc.clips()
        adapter.notifyDataSetChanged()
        empty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
    }
}
